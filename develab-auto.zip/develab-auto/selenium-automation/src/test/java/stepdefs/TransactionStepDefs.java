package stepdefs;

import driver.InitWebDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.TransactionPage;
public class TransactionStepDefs {

    TransactionPage transactionPage = new TransactionPage(InitWebDriver.driver);

    @Given("user already view product jacket")
    public void userAlreadyViewProductJacket() {transactionPage.viewProductJacket();
    }

    @When("user add to cart product jacket")
    public void userAddToCartProductJacket() {transactionPage.addProductJacket();
    }

    @Then("user success add to cart product jacket and view cart")
    public void userSuccessAddToCartProductJacketAndViewCart() {transactionPage.viewCart();}

    @Given("user already view product pants")
    public void userAlreadyViewProductPants() {transactionPage.viewProductPants();
    }

    @When("user add to cart product pants")
    public void userAddToCartProductPants() {transactionPage.addProductPants();
    }

    @Then("user success add to cart product pants and view cart")
    public void userSuccessAddToCartProductPantsAndViewCart() {transactionPage.viewCart();}

    @Given("user already view product whatsnew")
    public void userAlreadyViewProductWhatsNew() {transactionPage.viewProductWhatsNew();
    }

    @When("user add to cart product whatsnew")
    public void userAddToCartProductWhatsNew() {transactionPage.addProductWhatsNew();
    }

    @Then("user success add to cart product whats new and view cart")
    public void userSuccessAddToCartProductWhatsNewAndViewCart() {transactionPage.viewCart();}
}
