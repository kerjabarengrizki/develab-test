package config;

public class GlobalVariable {

    public final String baseUrl = "https://magento.softwaretestingboard.com/";
    public final String email = "rizkiqa@mailinator.com";
    public final String password = "Digit@l123";
}
