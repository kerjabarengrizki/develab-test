package pages;

import driver.InitWebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LoginPage extends BasePage {

    ChromeDriver driver;
    private final By inputEmail = By.id("email");
    private final By inputPassword = By.name("pass");
    private final By navbarSignIn = By.xpath("//div[@class='panel header']//a[contains(.,'Sign In')]");
    private final By buttonSignIn = By.xpath("//button[@class='action login primary']/span[.='Sign In']");

    private final By nameAccount = By.xpath("//div[@class='panel header']//span[@class='logged-in']");
    public LoginPage(ChromeDriver driver) {
        InitWebDriver.driver = driver;
    }

    public void goToLoginPage() {
        clickElement(navbarSignIn);
        waitUntil(ExpectedConditions.visibilityOfElementLocated(inputEmail));
        System.out.println("Redirected to login page");
    }

    public void inputForLogin(String email, String password) {
        setText(inputEmail, email);
        setText(inputPassword, password);
        System.out.println("user input email and password");
    }

    public void clickButtonLogin() {
        waitUntil(ExpectedConditions.visibilityOfElementLocated(buttonSignIn));
        clickElement(buttonSignIn);
        System.out.println("User do submit login");
    }

    public void verifySuccessLogin() {
        waitUntil(ExpectedConditions.visibilityOfElementLocated(nameAccount));
        System.out.println("User success login");
    }
}

