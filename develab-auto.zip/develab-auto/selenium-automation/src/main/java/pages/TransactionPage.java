package pages;

import driver.InitWebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
public class TransactionPage extends BasePage {

    ChromeDriver driver;
    private final By categoryWhatsNew = By.xpath("//span[.=\"What's New\"]");
    private final By categoryWoman = By.xpath("//span[.='Women']");
    private final By categoryMen = By.xpath("//span[.='Men']");
    private final By categoryJacket = By.xpath("//div[@class='categories-menu']//a[.='Jackets']");
    private final By categoryPants = By.xpath("//ul[2]//a[.='Pants']");
    private final By productJacket = By.xpath("//img[@alt='Proteus Fitness Jackshirt']");
    private final By productPants = By.cssSelector("[alt='Portia Capri']");
    private final By productWhatsNew = By.xpath("//div[@class='categories-menu']//a[@href='https://magento.softwaretestingboard.com/women/tops-women/tees-women.html']");
    private final By inputQty = By.id("qty");
    private final By addToCartBtn = By.id("product-addtocart-button");
    private final By selectSize = By.xpath("//div[@class='swatch-attribute size']//div[.='S']");
    private final By selectColor = By.xpath("//div[@class='swatch-attribute color']/div[@class='swatch-attribute-options clearfix']/div[2]");
    private final By cartCta = By.cssSelector(".showcart");
    private final By viewCart = By.xpath("//span[.='View and Edit Cart']");
    private final By checkoutBtn = By.xpath("//ul[@class='checkout methods items checkout-methods-items']//button[@class='action primary checkout']");

    public TransactionPage(ChromeDriver driver) {
        InitWebDriver.driver = driver;
    }

    public void viewProductJacket() {
        clickElement(categoryMen);
        waitUntil(ExpectedConditions.visibilityOfElementLocated(categoryJacket));
        clickElement(categoryJacket);
        waitUntil(ExpectedConditions.visibilityOfElementLocated(productJacket));
        clickElement(productJacket);
        clickElement(selectSize);
        clickElement(selectColor);
        clickElement(addToCartBtn);
        System.out.println("Success view to detail product jacket");
    }

    public void addProductJacket() {
        clickElement(selectSize);
        clickElement(selectColor);
        clickElement(addToCartBtn);
        System.out.println("Success add to cart product jacket");
    }

    public void viewProductPants() {
        clickElement(categoryWoman);
        waitUntil(ExpectedConditions.visibilityOfElementLocated(categoryPants));
        clickElement(categoryPants);
        waitUntil(ExpectedConditions.visibilityOfElementLocated(productPants));
        clickElement(productPants);
        clickElement(selectSize);
        clickElement(selectColor);
        clickElement(addToCartBtn);
        System.out.println("Success view detail product pants");
    }

    public void addProductPants() {
        clickElement(selectSize);
        clickElement(selectColor);
        clickElement(addToCartBtn);
        System.out.println("Success add to cart product pants");
    }

    public void viewProductWhatsNew() {
        clickElement(categoryWhatsNew);
        waitUntil(ExpectedConditions.visibilityOfElementLocated(productPants));
        clickElement(productPants);
        waitUntil(ExpectedConditions.visibilityOfElementLocated(selectSize));
        clickElement(selectSize);
        clickElement(selectColor);
        clickElement(addToCartBtn);
        System.out.println("Success view detail product whats new");
    }

    public void addProductWhatsNew() {
        clickElement(selectSize);
        clickElement(selectColor);
        clickElement(addToCartBtn);
        System.out.println("Success add to cart product whats new");
    }

    public void viewCart() {
        clickElement(cartCta);
        waitUntil(ExpectedConditions.visibilityOfElementLocated(viewCart));
        clickElement(viewCart);
        waitUntil(ExpectedConditions.visibilityOfElementLocated(checkoutBtn));
        System.out.println("Success redirect to cart");
    }


}
