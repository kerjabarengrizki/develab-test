# Selenium Automation Test Develab

## Overview
This project demonstrates automated testing using Selenium WebDriver with Java and Maven. This Project is for submission develab technical test for Automation Web on Magento Software Testing Board.

## Prerequisites
- Java Development Kit (JDK) installed
- Maven installed
- Web browser (e.g., Chrome, Firefox) installed

## Setup
1. Clone the repository:
   ```bash
   git clone https://github.com/kerjabarengrizki/develab-test.git
   cd develab-test
   
Install dependencies using Maven:

mvn clean install

Install dependencies using Maven:

mvn clean install

Running Tests

mvn test

Run individual tests by specifying the test class:

mvn -Dtest=TestClass test


##Copyright kerjabarengrizki@gmail.com